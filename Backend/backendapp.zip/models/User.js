import { DataTypes } from "sequelize";
import sequelize from "../config/db.js";

const User = sequelize.define(
  "User",
  {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    name: { type: DataTypes.STRING, allowNull: false },
    email: { type: DataTypes.STRING, allowNull: false, unique: true },
    password: { type: DataTypes.STRING, allowNull: false },
    role: {
      type: DataTypes.ENUM("admin", "user", "superadmin"),
      defaultValue: "user",
    },
  },
  {
    tableName: "users", // ✅ نام دقیق جدول
    timestamps: false, // یا true اگر created_at دارید
  }
);

export default User;
